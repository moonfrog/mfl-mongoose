Mongoose + Express examples
